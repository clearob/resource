package messagescheduler.external;

import messagescheduler.model.Message;

public class Gateway {

	
	public void send(Message msg)
	{
	
		System.out.println("Gateway sending message number:"+msg.getMessageId()+ " of group:"+msg.getGroupId());
	}
	
	
}
