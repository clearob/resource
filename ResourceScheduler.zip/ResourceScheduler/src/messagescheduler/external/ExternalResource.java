package messagescheduler.external;

public class ExternalResource {
	 private boolean available=true;

	public boolean isAvailable() {
		return this.available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}
	
	 
	 
}
