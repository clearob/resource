package messagescheduler.core;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.ConcurrentLinkedQueue;


import messagescheduler.external.ExternalResource;
import messagescheduler.external.Gateway;
import messagescheduler.model.Message;
import messagescheduler.prioritystrategy.AlternativePriorityStrategy;
import messagescheduler.prioritystrategy.NormalPriorityStrategy;
import messagescheduler.prioritystrategy.PriorityStrategy;

public class Scheduler {

	private static Gateway gateway;
	private static HashMap extResMsg=new HashMap();
	private static String queuelength;
	private static ArrayList<String> terminatedGroups=new ArrayList<String>();
	private static Vector<ExternalResource> externalResources;
	private static ConcurrentLinkedQueue<Message> queueMessage;

	private static Object lock = new Object();
	private static String groupCancellation;
	private static String selectedPriorityStrategy;
	private static PriorityStrategy priorityStrategy;





	public static void acceptMessage(Message msg) throws GenericException
	{
		System.out.println("**********incoming message id:"+msg.getMessageId()+" of group :"+msg.getGroupId()+"**************");



		if(terminatedGroups.contains(msg.getGroupId()))
		{
			throw new GenericException("A termination message has been received for this group:"+msg.getGroupId());
		}

		synchronized(lock)
		{
			int k=checkAvailabilityResource();


			//resource available
			if (k>-1)
			{
				System.out.println("accepeted message id:"+msg.getMessageId()+" of group :"+msg.getGroupId());
				sendMessage(msg,k);
			}
			//resource not available so enqueue incoming message
			else
			{	
				
				//check the queue if there are too many pending messages  to process
				
				if(queueMessage.size() < Integer.parseInt(queuelength))
				{
					System.out.println("accepeted  in queue message id:"+msg.getMessageId()+" of group :"+msg.getGroupId());
					queueMessage.add(msg);
					
				}else
				{	
					throw new GenericException("Too many messages in the queue");
				}
				getQueueStatus();

			}
		}
	}




	private static void getQueueStatus()
	{
		//status of queue
		Iterator<Message> itr= queueMessage.iterator();
		System.out.println("These messages are in queue:");
		while(itr.hasNext()){
			Message msg=itr.next();
			System.out.println("id message:"+ msg.getMessageId()+" id group:"+ msg.getGroupId());	
		}
	}


	private static void getExternalResoucesStatus()
	{

		System.out.println("*****getExternalResoucesStatus*********");
		//status of resources
		for (int l=0;l<externalResources.size();l++)
			System.out.println("resource status number:"+l+" is:"+ (externalResources.get(l).isAvailable() ? "free" : "busy"));
	}


	public static void processed(Message msg) throws GenericException
	{
		System.out.println("*****processed*********");
		int indexRes=-1;

		for (Object o : extResMsg.keySet()) {
			if (extResMsg.get(o).equals(msg)) {
				String ind = o == null ? "null" : (o.getClass().isArray() ? Arrays.toString((Object[])o) : o.toString());
				indexRes=Integer.parseInt(ind);
			}
		}

		if(indexRes>-1)
		{	
			synchronized(lock)
			{
			externalResources.get(indexRes).setAvailable(true);
			
			String groupId=msg.getGroupId();
			dequeueMsg(indexRes,groupId);
			}
		}
	}


	// used only for test purpose
	public static void processed(Message msg, int indexRes) throws GenericException {
		System.out.println("*****inside processed method for message id:"+msg.getMessageId()+" of group:"+msg.getGroupId()+"*********");

		if(indexRes>-1)
		{	
			externalResources.get(indexRes).setAvailable(true);
			String groupId=msg.getGroupId();
			dequeueMsg(indexRes,groupId);
		}

	}


	// for testing
	public static ConcurrentLinkedQueue<Message> getQueueMessage() {
		return queueMessage;
	}


	public static void cancellation(String groupId)
	{
		groupCancellation=groupId;
	}


	private static int checkAvailabilityResource() {
		int found=-1;
		for (int j=0;j<externalResources.size();j++)
		{	
			ExternalResource extRes = (ExternalResource)externalResources.get(j);
			if (extRes.isAvailable())
			{
				found=j;
				break;
			}	
		}
		return found;
	}




	private static void sendMessage(Message msg, int index) throws GenericException
	{
		System.out.println("*****inside methdo sendMessage*********");
		if(msg.isTerminationMessage())
			terminatedGroups.add(msg.getGroupId());
		ExternalResource extRes = (ExternalResource)externalResources.get(index);

		if(!groupCancellation.equalsIgnoreCase(msg.getGroupId())) 
		{
			extRes.setAvailable(false);
			gateway.send(msg);
			extResMsg.put(index, msg);
		}
		else
			throw new GenericException("No more messages belonging to this group could be sent to exeternal resource");

		//status of resources
		getExternalResoucesStatus();

	}


	private static void dequeueMsg(int indexRes,String groupId) throws GenericException {

		System.out.println("*****inside method dequeueMessage*********");
		if(queueMessage.isEmpty() || groupCancellation.equalsIgnoreCase(groupId))
			return;

		
			PriorityStrategy priorityStrategy=getStrategy();
			Message msg=priorityStrategy.popNextMessage(queueMessage,groupId);

			if (msg!=null && externalResources.get(indexRes).isAvailable())
			{
				sendMessage(msg,indexRes);	
				queueMessage.remove(msg);
			}	
			getQueueStatus();
		
		
	}


	private static PriorityStrategy getStrategy() {
		if(priorityStrategy==null && selectedPriorityStrategy.equalsIgnoreCase("normal"))
			priorityStrategy=new NormalPriorityStrategy();
		else if	(priorityStrategy==null && selectedPriorityStrategy.equalsIgnoreCase("alternative"))
			priorityStrategy=new AlternativePriorityStrategy();

		return priorityStrategy;
	}


	static 
	{

		Properties prop = new Properties();
		InputStream input = null;

		try {


			gateway=new Gateway();
			// load a properties file
			input = new FileInputStream("config.properties");
			prop.load(input);

			queuelength=prop.getProperty("queuelength");

			selectedPriorityStrategy=prop.getProperty("prioritystrategy");
			//number of external resource instantiated
			int num_extresource=Integer.parseInt(prop.getProperty("external_resources"));
			//create instance of external resources...
			externalResources=new Vector(num_extresource);
			for (int k=0;k<num_extresource;k++)
			{
				externalResources.add(new ExternalResource());
			}

			//initialize queues
			queueMessage=new ConcurrentLinkedQueue<Message>();

			//initialize group cancellation
			groupCancellation="";



		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}





}
