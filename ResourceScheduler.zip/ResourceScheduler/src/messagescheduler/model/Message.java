package messagescheduler.model;

public class Message {
	
	private int messageId;
	private String groupId;
	private boolean terminationMessage=false;
	
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public boolean isTerminationMessage() {
		return terminationMessage;
	}
	
	
	public Message(int messageId, String groupId, boolean terminationMessage) {
		super();
		this.messageId = messageId;
		this.groupId = groupId;
		this.terminationMessage = terminationMessage;
	}
	
	public Message(int messageId, String groupId) {
		super();
		this.messageId = messageId;
		this.groupId = groupId;
	}
	
	
	
	
	

}
