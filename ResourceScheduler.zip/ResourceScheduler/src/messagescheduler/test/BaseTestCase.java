package messagescheduler.test;

import static org.junit.Assert.*;

import messagescheduler.core.Scheduler;
import messagescheduler.model.Message;

import org.junit.Before;
import org.junit.Test;

public class BaseTestCase {


	//execute before test
	@Before
	public void before() {

		try{
			Message msg1A=new Message(1,"groupA",true);
			Message msg2B=new Message(2,"groupB");
			Message msg2A=new Message(2,"groupA");
			Message msg1C=new Message(1,"groupC");
			Scheduler.acceptMessage(msg1A);
			Scheduler.acceptMessage(msg2B);
			Scheduler.acceptMessage(msg1C);
			Scheduler.acceptMessage(msg2A);
			Scheduler.processed(msg2B);
		}catch(Exception ex){
			System.out.println("Error :"+ex.getMessage());
		}
	}


	@Test
	public void test() {

		
		assertTrue(Scheduler.getQueueMessage().size()>=0);
	}

}
