package messagescheduler.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import messagescheduler.core.Scheduler;
import messagescheduler.model.Message;

public class MultiEntitityTestCase {



	@Before
	public void before() {

		

	
		
		
		
		new Thread()
		{

			public void run() {
				try{
					
					Message msg1A=new Message(1,"groupA"); 
					Message msg2B=new Message(2,"groupB");
					Message msg2A=new Message(2,"groupA");

					Message msg1C=new Message(1,"groupC"); 
					Message msg2C=new Message(2,"groupC");
					Scheduler.acceptMessage(msg1A);
					Scheduler.acceptMessage(msg2B);
					Scheduler.acceptMessage(msg2A);
					Scheduler.acceptMessage(msg1C);
					Scheduler.acceptMessage(msg2C);
					
					
					
					

				}catch(Exception e){System.out.println("Error :"+e.getMessage());}
			}
		}.start();

		
		
		//emulates a resource with a processed message
		new Thread()
		{

			public void run() {
				try {
					//Thread.sleep(500);
					Message msg2B=new Message(2,"groupB");
					Scheduler.processed(msg2B,1);   // created for test purpose
				} catch (Exception e) {

					System.out.println("Error :"+e.getMessage());

				}
			}
		}.start();
		
		
		
		
		

	}

	@Test
	public void test() {

		assertTrue(Scheduler.getQueueMessage().size()>= 0);
	}

}
