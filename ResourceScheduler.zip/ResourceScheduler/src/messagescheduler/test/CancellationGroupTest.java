package messagescheduler.test;

import static org.junit.Assert.assertTrue;
import messagescheduler.core.Scheduler;
import messagescheduler.model.Message;

import org.junit.Before;
import org.junit.Test;

public class CancellationGroupTest {

	//execute before test
		@Before
		public void before() {

			try{
				Message msg1A=new Message(1,"groupA");
			
				Message msg2A=new Message(2,"groupA");
				
				Scheduler.acceptMessage(msg1A);
				Scheduler.cancellation("groupA");
				Scheduler.acceptMessage(msg2A);
				
			}catch(Exception ex){
				System.out.println("Error :"+ex.getMessage());
			}
		}


		@Test
		public void test() {
	
			assertTrue(Scheduler.getQueueMessage().size()>=0);
		}

	
	
}
