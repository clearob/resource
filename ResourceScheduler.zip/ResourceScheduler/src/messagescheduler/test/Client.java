package messagescheduler.test;

import messagescheduler.core.Scheduler;
import messagescheduler.model.Message;

public class Client {

	public static void main(String[] args)
	{

		try{
			Message msg1A=new Message(1,"groupA");
			Message msg2B=new Message(2,"groupB");
			Message msg2A=new Message(2,"groupA");
			Message msg1C=new Message(1,"groupC",true); //build a message with the indication that it is the last message for this group
			Message msg1D=new Message(1,"groupD");
			Message msg2C=new Message(2,"groupC");
			Message msg1E=new Message(1,"groupE");
			Scheduler.acceptMessage(msg1A);
			Scheduler.acceptMessage(msg1C);
			Scheduler.acceptMessage(msg2B);
			Scheduler.acceptMessage(msg2C);
			Scheduler.acceptMessage(msg2A);
			
			
			Scheduler.acceptMessage(msg1D);
			Scheduler.acceptMessage(msg2C);
			Scheduler.acceptMessage(msg1E);
			Scheduler.processed(msg2B);
		}catch(Exception ex){
			System.out.println("Error :"+ex.getMessage());
		}
	}
	
}
