package messagescheduler.prioritystrategy;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

import messagescheduler.model.Message;

public class AlternativePriorityStrategy implements PriorityStrategy{

	@Override
	public Message popNextMessage(ConcurrentLinkedQueue<Message> queueMessage,String groupId) {
		//Lifo serving mechanism
		Message msg = null;
		Message firstAvailableMessage=null;
		
		Message[] msgs = new Message[queueMessage.size()];
		Message[] arrmsgs= queueMessage.toArray(msgs);
		
		int index=arrmsgs.length-1;
		for (int j=index ; j>=0; j--)
		{
			Message tmp=arrmsgs[j];
			if(j==index)
				firstAvailableMessage=tmp;
			if(tmp.getGroupId().equalsIgnoreCase(groupId))
			{
				msg=tmp;
				break;
			}
			
		}
		if(msg==null)
			msg=firstAvailableMessage;
		
		return msg;
		
	}

}
