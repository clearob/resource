package messagescheduler.prioritystrategy;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

import messagescheduler.model.Message;

public class NormalPriorityStrategy implements PriorityStrategy{

	@Override
	public Message popNextMessage(ConcurrentLinkedQueue<Message> queueMessage, String groupId) {
		//Fifo serving mechanism
		
		Message msg = null;
		Message firstAvailableMessage=null;
		Iterator<Message> itr= queueMessage.iterator();
		int currentpos=0;
		while(itr.hasNext()){
			Message tmp=itr.next();
			if(currentpos==0)
				firstAvailableMessage=tmp;
			if(tmp.getGroupId().equalsIgnoreCase(groupId))
			{
				msg=queueMessage.peek();
				break;
			}
			currentpos++;
		}
		if(msg==null)
			msg=firstAvailableMessage;
		
		System.out.println("get from queue message id:"+msg.getMessageId()+" of group:"+msg.getGroupId());
		return msg;
	}

}
