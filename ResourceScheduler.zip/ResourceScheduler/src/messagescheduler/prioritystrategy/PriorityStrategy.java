package messagescheduler.prioritystrategy;

import java.util.concurrent.ConcurrentLinkedQueue;

import messagescheduler.model.Message;

public interface PriorityStrategy {

	public Message popNextMessage(ConcurrentLinkedQueue<Message> queueMessage,String groupId);
	
	
}
