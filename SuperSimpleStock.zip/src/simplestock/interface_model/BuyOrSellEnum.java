package simplestock.interface_model;



public enum BuyOrSellEnum {
  	 BUY,
  	 SELL;

}
