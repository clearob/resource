package simplestock.interface_model;


public enum StockTypeEnum {  
  	 COMMON,
   	 PREFERRED;

}
